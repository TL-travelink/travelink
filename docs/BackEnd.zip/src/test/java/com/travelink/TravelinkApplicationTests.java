package com.travelink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
