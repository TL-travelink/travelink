<script setup>

</script>

<template>
  <button
      class="mx-auto lg:mx-0 hover:underline gradient text-white font-bold rounded-full py-4 px-8 shadow-lg focus:outline-none focus:shadow-outline transform transition hover:scale-105 duration-300 ease-in-out"
  >
    <slot></slot>
  </button>
</template>

<style scoped>

</style>